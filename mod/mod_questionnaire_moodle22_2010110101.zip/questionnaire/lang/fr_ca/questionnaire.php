<?PHP // $Id$ 
      // questionnaire.php - created with Moodle 1.7.2 + (2006101020)
$string['dateformatting'] = 'Utilisez le format année/mois/jour, par exemple pour le 14 mars 1945:&nbsp; <strong>1945-3-14</strong>';
$string['strfdate'] = '%Y-%m-%d';
$string['strfdateformatcsv'] = 'Y-m-d H:i:s';

?>
