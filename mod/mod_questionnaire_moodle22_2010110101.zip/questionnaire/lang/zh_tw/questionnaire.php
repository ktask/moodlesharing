<?PHP // $Id$ 
      // questionnaire.php - created with Moodle 1.4.3 (2004083130)


$string['alreadyfilled'] = '您已完成本問卷. 感謝您的填答.';
$string['modulename'] = '問卷(意見)調查';
$string['modulenameplural'] = '問卷(意見)調查';
$string['mustcomplete'] = '<b>您必須<i>現在</i>完成本問卷以記錄結果. 您不被允許在其它時間重填問卷</b><br><br>';
$string['notavail'] = '該問卷(意見)調查表尚未開放.請稍後再試.';
$string['qmanage'] = '管理選項';
$string['qmanagetitle'] = 'phpESP 問卷管理';
$string['qtype'] = '型式';
$string['questionnaireid'] = '問卷';
$string['respondenttype'] = '回應方式';

?>
