Tradução do módulo questionnaire (phpESP) para o idioma português do Brasil.

Traduzido por 		: Luiz Paulo Leite Machado (lunixbr@gmail.com)
Data da Tradução 	: 21/06/2006
Data da última revisão	: 12/07/2006
Traduzido para o projeto Casa Brasil (www.casabrasil.gob.br)
Avalida para a versão do módulo 

Avaliada para versão 2006031702 do módulo.


Mover o diretório pt_br para dentro do diretório [Instalação do Moodle]/mod/questionnaire/lang/


Translated of module questionnaire (phpESP) for the portugues of Brazil language

Translated for 	  		: Luiz Paulo Leite Machado (lunixbr@gmail.com)
Date of translation		: 2006/06/21
Date of the last revision	: 2006/07/12
Translated for project Casa Brasil (www.casabrasil.gov.br)

Evaluated for version 2006031702 of module.

Move the directory pt_br for inside the directory [Moodle Install]/mod/questionnaire/lang/
