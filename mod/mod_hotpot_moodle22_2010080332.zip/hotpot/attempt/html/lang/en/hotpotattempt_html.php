<?php
$string['pluginname'] = 'HTML output formats';
