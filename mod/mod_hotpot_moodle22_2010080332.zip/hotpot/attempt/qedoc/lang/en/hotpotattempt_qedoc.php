<?php
$string['pluginname'] = 'Qedoc output formats';
