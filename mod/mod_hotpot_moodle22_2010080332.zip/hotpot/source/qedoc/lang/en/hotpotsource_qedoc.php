<?php
$string['pluginname'] = 'Qedoc source files';
